[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=7594825&assignment_repo_type=AssignmentRepo)

# project2-2021

此项目 Django 连接数据库为 mysql。

在settings.py中进行相应的配置。

运行

```shell
>> python manage.py makemigrations auctions
>> python manage.py migrate
>> python manage.py runserver
```

